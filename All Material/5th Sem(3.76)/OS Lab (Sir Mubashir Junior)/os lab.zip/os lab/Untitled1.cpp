#include<iostream>
using namespace std;

int main(){
	int pages[]={2,6,2,4,8};
	int frames[3]={-1,-1,-1};
	int hit,fault;
	
	for(int i=0;i<sizeof(pages)/sizeof(pages[0]);i++){
		
		for(int j=0;j<3;j++){
			if(frames[j]==pages[i]){
				hit++;
				break;
			}
			else if(j==2){
				fault++;
				//insertion
				for(int k=0;k<3;k++){
					if(frames[k]==-1){
						frames[k]=pages[i];
						break;
					}
					else if(k==3){
						for(int x=0;x<2;x++){
						
						frames[x+1]=frames[x];
					}
					frames[2]=pages[i];
					}
				}
				
			}
		}
		
		
	}
	return 0;
}
