#include<iostream>
#include <algorithm> 
using namespace std;

int main(){
	//================================FCFS

//	int process,at[5],bt[5],ct[5],tat[5],wt[5];
//	cout<<"Enter no of process: "<<endl;
//	cin>>process;
//	
//	//reading arrival and burst time
//	for(int i=0;i<process;i++){
//		cout<<endl<<"Enter arrival time of the process "<<i+1<<" ";
//		cin>>at[i];
//		cout<<endl<<"Enter burst time of the process "<<i+1<<" ";
//		cin>>bt[i];
//	}
//	
//	ct[0]=at[0]+bt[0];
//	
//	//calculating completion time
//	for(int j=1;j<=process;j++){
//		ct[j]=ct[j-1]+bt[j];
//	}
//	
//	//calculating turnaround time
//	for(int k=0;k<process;k++){
//		tat[k]=ct[k]-at[k];
//	}
//	
//	//calculating waiting time
//	for(int l=0;l<process;l++){
//		wt[l]=tat[l]-bt[l];
//	}
//	
//	//printing values
//	cout<<"Number of Process: "<<process<<endl;
//	
//	cout<<"Arrival time"<<endl;
//	for(int x=0;x<process;x++){
//		cout<<at[x]<<" ";
//	}
//	
//	cout<<endl<<"Burst time"<<endl;
//	for(int y=0;y<process;y++){
//		cout<<bt[y]<<" ";
//	}
//		
//	cout<<endl<<"Completion time"<<endl;
//	for(int z=0;z<process;z++){
//		cout<<ct[z]<<" ";
//	}
//	
//	cout<<endl<<"Turn around time"<<endl;
//	for(int z=0;z<process;z++){
//		cout<<tat[z]<<" ";
//	}
//	
//	cout<<endl<<"Waiting time"<<endl;
//	for(int z=0;z<process;z++){
//		cout<<wt[z]<<" ";
//	}

//================================SJF

	int process,at[5],bt[5],ct[5],tat[5],wt[5],rq[5];
	cout<<"Enter no of process: "<<endl;
	cin>>process;
	
	//reading arrival and burst time
	for(int i=0;i<process;i++){
		cout<<endl<<"Enter arrival time of the process "<<i+1<<" ";
		cin>>at[i];
		cout<<endl<<"Enter burst time of the process "<<i+1<<" ";
		cin>>bt[i];
	}
	
	int minAt =  *min_element(at, at + process);
	
	cout<<minAt;
	
	

	
	return 0;
}
