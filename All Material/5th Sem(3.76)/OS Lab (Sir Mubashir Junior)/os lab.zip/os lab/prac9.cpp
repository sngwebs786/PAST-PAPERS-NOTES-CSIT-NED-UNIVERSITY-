#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;

int main(){
	int process[3]={2,4,7};
	int memory[4]={6,2,7,3};
	string allocated[4] ={"F","F","F","F"};
	
	
	/////////////////////////////////////////////////first fit
//	for(int i=0;i<3;i++){
//		for(int j=0;j<8;j++){
//			if(memory[j]>=process[i] && allocated[j]=="F"){
//				cout<<"Process "<<i+1<<" of size "<<process[i]<<" is allocated to memory of size "<<memory[j]<<endl;
//				allocated[j]="T";
//				break;
//			}
//		}
//	}
	
	
	///////////////////////////////////////////////// best fit
	
	//sorting the memory
//
//	for(int x=0;x<3;x++){
//		for(int y=0;y<3;y++){
//			if(memory[y]>memory[y+1]){
//				int temp = memory[y+1];
//				memory[y+1]=memory[y];
//				memory[y]=temp;
//				}
//		}
//	}
//	
//	
//	for(int i=0;i<3;i++){
//		for(int j=0;j<8;j++){
//			if(memory[j]>=process[i] && allocated[j]=="F"){
//				cout<<"Process "<<i+1<<" of size "<<process[i]<<" is allocated to memory of size "<<memory[j]<<endl;
//				allocated[j]="T";
//				break;
//			}
//		}
//	}
	
	
		///////////////////////////////////////// worst fit
	
	//sorting the memory

//	for(int x=0;x<3;x++){
//		for(int y=0;y<3;y++){
//			if(memory[y]<memory[y+1]){
//				int temp = memory[y+1];
//				memory[y+1]=memory[y];
//				memory[y]=temp;
//				}
//		}
//	}
//	
//	
//	for(int i=0;i<3;i++){
//		for(int j=0;j<8;j++){
//			if(memory[j]>=process[i] && allocated[j]=="F"){
//				cout<<"Process "<<i+1<<" of size "<<process[i]<<" is allocated to memory of size "<<memory[j]<<endl;
//				allocated[j]="T";
//				break;
//			}
//		}
//	}
	return 0;
}
