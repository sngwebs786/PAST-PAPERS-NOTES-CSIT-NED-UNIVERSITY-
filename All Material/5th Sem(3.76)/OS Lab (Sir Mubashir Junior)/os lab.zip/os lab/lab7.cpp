#include<iostream>
#include <vector>
using namespace std;

int main(){
	std::vector< int > notExecutedProcess;
	string process[5]={"P1","P2","P3","P4","P5"};
	string resources[5]={"A","B","C","D"};
	int givenAllocation[4]={9,13,10,11};
	//Total Allocated As,Bs,Cs,Ds
	int totalAllocation[4]={0,0,0,0};
	int alloc[5][4]={{4,0,0,1},{1,1,0,0},{1,2,5,4},{0,6,3,3},{0,2,1,2}};
	int max[5][4]={{6,0,1,2},{1,7,5,0},{2,3,5,6},{1,6,5,3},{1,6,5,6}};
	int reqAlloc[5][4];
	int availMat[4];
	int sum=0;
	bool flag=false;
	
	
	
	for(int i=0;i<5;i++){
		for(int j=0;j<4;j++){
			reqAlloc[i][j]=max[i][j]-alloc[i][j];
		}
	}
	
	for(int t=0;t<4;t++){
		sum=0;
		for(int i=0;i<5;i++){
			sum=sum+alloc[i][t];
		}
		totalAllocation[t]=sum;
	}
	

	cout<<"Instance of A,B,C,D"<<endl;
	cout<<"==================="<<endl;
	for(int k=0;k<4;k++){
		cout<<resources[k]<<": "<<givenAllocation[k]<<endl;
	}
	
	cout<<"\nAllocated Resources"<<endl;
	cout<<"==================="<<endl;
	for(int x=0;x<5;x++){
		for(int y=0;y<4;y++){
			cout<<" "<<alloc[x][y];
		}
		cout<<endl;
	}
	
	cout<<"\nMax Resources"<<endl;
	cout<<"============="<<endl;
	for(int x=0;x<5;x++){
		for(int y=0;y<4;y++){
			cout<<" "<<max[x][y];
		}
		cout<<endl;
	}
	
	cout<<"\nRequired Allocation"<<endl;
	cout<<"==================="<<endl;
	for(int x=0;x<5;x++){
		for(int y=0;y<4;y++){
			cout<<" "<<reqAlloc[x][y];
		}
		cout<<endl;
	}
	
	cout<<"\nFirst Availability Matrix: ";
	for(int x=0;x<4;x++){
		availMat[x]=givenAllocation[x]-totalAllocation[x];
		cout<<" "<<availMat[x];
	}
	
	for(int a=0;a<5;a++){
		cout<<"\n\nChecking for "<< process[a]<<"..."<<endl;	
		
		for(int b=0;b<4;b++){
			if(availMat[b]>=reqAlloc[a][b]){
				flag=true;
			}
			else{
				notExecutedProcess.push_back(a);
				flag=false;
				break;
			}
		}
		
				
		if(flag){
			cout<<"\n **** "<<process[a]<<" executed!! ****"<<endl;
			cout<<"New Availability matrix: "<<endl;
				for(int c=0;c<4;c++){
					availMat[c]=availMat[c]+alloc[a][c];
					cout<<" "<<availMat[c];
			}
		
		}
		else{
			cout<<"\n ???? "<<process[a]<<" Not executed!! ????"<<endl;
			cout<<"New Availability matrix: "<<endl;
			for(int c=0;c<4;c++){
					cout<<" "<<availMat[c];
			}
		}
				
	}
	

	for(int g=0;g<notExecutedProcess.size();g++){
		cout<<"\n\nChecking for process "<<notExecutedProcess[g]+1<<" again";
		int a = notExecutedProcess[g];
	
		for(int b=0;b<4;b++){
			if(availMat[b]>=reqAlloc[a][b]){
				flag=true;
			}
			else{
				flag=false;
				break;
			}
		}
	
				
		if(flag){
			cout<<"\n\n **** "<<process[a]<<" executed!! ****"<<endl;
			cout<<"\nNew Availability matrix: "<<endl;
				for(int c=0;c<4;c++){
					availMat[c]=availMat[c]+alloc[a][c];
					cout<<" "<<availMat[c];
			}
		
		}
		else{
			cout<<"\n ???? "<<process[a]<<" Not executed!! ????"<<endl;
			cout<<"New Availability matrix: "<<endl;
			for(int c=0;c<4;c++){
					cout<<" "<<availMat[c];
			}
		}
	}	
	return 0;
}










