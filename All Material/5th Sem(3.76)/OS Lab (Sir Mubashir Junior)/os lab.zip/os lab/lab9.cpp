#include<iostream>
#include <cstdlib>

using namespace std;

int main(){
//	size of mem is 5, and 1st block is of 4MB, 2nd is 10MB...
	int mem[5] = {4,10,2,15,3};
//	there are 3 processes, 1st is of 5mb,2nd is 6mb and 3rd is 12mb
	int process[3]={5,6,2};
	int temp=process[0]-mem[0];
	int loc[5];
	for(int i=0;i<sizeof(process) / sizeof(int);i++){
		for(int j=0;j<sizeof(mem) / sizeof(int) ;j++){
			if(mem[j]!=0){
				int sub = abs(process[i]-mem[j]);
				if(sub<temp){
					temp=j;
				}
			}
		}
		
		cout<<temp;
		mem[temp]=0;
//		loc[0]=temp;
	}
	
//	for(int k=0;k<sizeof(loc) / sizeof(int);k++){
//		cout<<loc[k]<<endl;
//	}
	return 0;
}
